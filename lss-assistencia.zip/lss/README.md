# LSS Assistência Técnica

Site cinematográfico em React, TypeScript, Vite, React Three Fiber e GSAP. O smartphone 3D é modelado no Blender.

## Rodar
```
npm install
npm run dev
```
Para o botão de WhatsApp, copie `.env.example` para `.env` e preencha `VITE_WHATSAPP` com o número (só dígitos, com DDI).

## Modelo 3D
`npm run model` executa `blender/build_phone.py` e regera `public/models/phone.glb` (requer o Blender 4.x no PATH).

## Estado
Front-end apenas. O agendamento gera uma mensagem para o WhatsApp. Não há backend de horários.
